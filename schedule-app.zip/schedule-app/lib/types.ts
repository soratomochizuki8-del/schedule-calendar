// lib/types.ts
export interface UserMark {
  name: string;
  color: string;
}

export interface DayMarks {
  [dateKey: string]: UserMark[];
}

export interface CalendarDoc {
  marks: DayMarks;
  totalCount: number;
  updatedAt: number;
}
